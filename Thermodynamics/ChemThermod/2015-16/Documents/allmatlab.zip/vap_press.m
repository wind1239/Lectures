function f = vap_press(T)

global A B C P x2

x1 = 1-x2;

P_i = 10.^(A-B./(T+C));
k = P_i./P;

f = 1 - k(1)*x1 - k(2)*x2;

