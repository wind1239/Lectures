% Problem 2
%Tae H Han
%University of Washington
%August 6, 1997
%
%
%	2.4 Problem Statement
%   Xylene, styrene, toluene, and benzene are to be separated with the
%   array of distillation columns in Figure 1.  F, D, B, D1, B1, D2, and
%   B2 are the molar flow rates in mol/min.
%
%   Material balances on individual components on the overall separation
%   train yield the equation set(6):
%	   Xylene: 0.07D1+0.18B1+0.15D2+0.24B2=0.15*70
%      Styrene: 0.04D1+0.24B1+0.10D2+0.65B2=0.25*70
%      Toluene: 0.54D1+0.42B1+0.54D2+0.10B2=0.40*70
%      Benzene: 0.35D1+0.16B1+0.21D2+0.01B2=0.20*70
%
A=[0.07 0.18 0.15 0.24
   0.04 0.24 0.10 0.65
   0.54 0.42 0.54 0.10
   0.35 0.16 0.21 0.01];
f = [0.15*70 0.25*70 0.40*70 0.2*70];
disp('Solution for D1 B1 D2 B2 is:')
X = A\f'
% solution is 26.25 17.50 8.75 17.50

%   Overall balances and individual components balances on column#2 can
%   be used to determine the molar flow rate and mole fractions from the
%   equation of stream D from(7):
%
%	Molar Flow Rates:  D=D1+B1
%
%	   Xylene: X_Dx*D=0.07D1+0.18B1
%      Styrene: X_Ds*D=0.04D1+0.24B1
%      Toluene: X_Dt*D=0.54D1+0.42B1
%      Benzene: X_Db*D=0.35D1+0.16B1
%
%   Where:	X_Dx=mole fraction of Xylene
%		X_Ds=mole fraction of Styrene
%		X_Dt=mole fraction of Toluene
%		X_Db=mole fraction of Benzene
%
%Use the balance over column#2
D1 = X(1);
B1 = X(2);
disp ('Solve for Column 2')
D=D1+B1						%43.75 mol/min
X_Dx=(0.07*D1+0.18*B1)/D	%0.114 mole fraction
X_Ds=(0.04*D1+0.24*B1)/D	%0.120 mole fraction
X_Dt=(0.54*D1+0.42*B1)/D	%0.492 mole fraction
X_Db=(0.35*D1+0.16*B1)/D	%0.274 mole fraction


%   Similarly, overall balances and individual component balances on
%   column #3 can be used to determine the molar flow rate and mole
%   fractions of stream B from the equation set(8):
%
%	Molar Flow Rates: B=D2+B2
%
%	   Xylene: X_Bx*B=0.15D2+0.24B2
%      Styrene: X_Bs*B=0.10D2+0.65B2
%      Toluene: X_Bt*B=0.54D2+0.10B2
%      Benzene: X_Bb*B=0.21D2+0.01B2
%
%Use the balance over column#3
D2 = X(3);
B2 = X(4);
disp('Solve for Column 3')
B=D2+B2						%26.25 mol/min
X_Bx=(0.15*D2+0.24*B2)/B	%0.2100 mole fraction
X_Bs=(0.10*D2+0.65*B2)/B	%0.4667 mole fraction
X_Bt=(0.54*D2+0.10*B2)/B	%0.2467 mole fraction
X_Bb=(0.21*D2+0.01*B2)/B	%0.0767 mole fraction

