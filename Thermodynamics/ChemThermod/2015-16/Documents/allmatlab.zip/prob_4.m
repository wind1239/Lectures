%filename Prob_4.m
global Cao Cbo Kci Kcii Kciii cvector

% define constants
Cao = 1.5; Cbo=1.5; Kci= 1.06; Kcii= 2.63; Kciii= 5;

%set initial conditions

% Initial guess and set tolerance
% remove the % in front of the desired initial guess
cvector=[1.5 1.5 0 0 0 0 0]; %initial guess, part a
%cvector=[-.5 -1.5 -1 1 1 2 1];  %initial guess, part b
%cvector=[-18.5 -28.5 -10 10 10 20 10]; %initial guess, part c
guess=cvector;

%call fsolve
y = fsolve('prob4',guess)
