%	Problem 8
%	Binary Batch Distillation

clear

global A B C P T_guess

A = [6.90565 6.95464];
B = [1211.033 1344.8];
C = [220.79 219.482];
P = 1.2*760;								%	mmHg
Lo = 100;									%	moles
x_start = 0.40;								%	moles of toluene
x_final = 0.80;								%	moles of toluene
T_guess = (80.1+110.6)/2;					%	C
xspan = [x_start x_final];
[x L] = ode45('distill',xspan,Lo);
% For Version 4, use
%[x L] = ode45('distill',x_start,x_final,Lo);
plot(x,L,'r')
title('Batch Distillation')
xlabel('Mole Fraction of Toluene')
ylabel('Moles of Liquid')
output = [x L];
save batch.dat output -ascii
