function y3=fit_c(p)
global vp T
% function to fit vapor pressure to curve 3
a = p(1);
b = p(2);
c = p(3);
f = log10(vp) - a + b./(T+c);
%f = vp - 10.^(a - b./(T+c));
y3=sum(f.*f);
