%filename Prob_3c.m

% Make vp and T available in fit2
global vp T

%To solve part c, insert the data:
vp = [    1     5    10    20    40    60   100   200   400   760]
T = [-36.7  -19.6  -11.5   -2.6   7.6   15.4   26.1 42.2   60.6   80.1]

% set initial guesses of parameters
p0(1) = 10;
p0(2) = 2000;
p0(3) = 273;

% call least squares minimization
ls = fmins('fit_c',p0)

%The result is ls = 5.7673  677.09   153.89.

% To compute the sum of squares of errors:
vpfit1=(vp - 10.^(ls(1) - ls(2)./(T+ls(3))))
norm(vpfit1)
% norm = 16.3412

%To compute the norm based on the logarithm of the vapor pressure
vpfit2 = log10(vp) - (ls(1) - ls(2)./(T+ls(3)));
norm(vpfit2)
% norm = 0.0472281

