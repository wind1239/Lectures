% filename anyl7.m
function cc=anyl7(pos)
global L k Dab Cao 
term1=L*(k/Dab)^0.5; 
cc=Cao*(cosh(term1*(1-pos/L))/cosh(term1));

