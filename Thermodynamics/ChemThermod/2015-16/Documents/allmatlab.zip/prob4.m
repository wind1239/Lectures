%filename prob4.m
function f = prob4(cvector)
global Cao Cbo Kci Kcii Kciii
% cvector are the concentrations of the seven species. cvector(1) is the concentration of species a,
% cvector(2) is the concentration of b etc.

f(1)= cvector(3)*cvector(4)-Kci*cvector(1)*cvector(2);
f(2)= cvector(6)*cvector(5)-Kcii*cvector(2)*cvector(3);
f(3)= cvector(7)- Kciii*cvector(1)*cvector(5);
f(4)= Cao - cvector(1) - cvector(4) - cvector(7);
f(5)= Cbo - cvector(2) - cvector(4) - cvector(6);
f(6)= cvector(4) - cvector(6) - cvector(3);
f(7)= cvector(6) - cvector(5)- cvector(7);

