%filename Prob_10.m

clear all
clc
global qsetpt taud taui Kc Tsetpt onoff

qsetpt= 1e4; taud=1; taui=2; Tsetpt=80;
Kc= input('enter the gain')
onoff=input('enter 0 for no integrator, enter 1 if integrator on')  

% initialization 
to=0;  tfin=200; 	% limits of integration
tspan = [to tfin];
To=[80 80 80 0]; 	%  initial condition of system. Tank Temp, Outlet Temp
			% Thermocouple Temp and error signal
[t,T] = ode45('tempdyn',tspan,To);
% For version 4 use
%[t,T] = ode45('tempdyn',to,tfin,To);

T
plot(t,T(:,1),'r', t,T(:,2),'ro',t,T(:,3),'r:')
grid
title('Temperatue vs time')
xlabel('time in minutes')
ylabel('Temperature in C')
legend('Tank','Outlet T','Measured T')

