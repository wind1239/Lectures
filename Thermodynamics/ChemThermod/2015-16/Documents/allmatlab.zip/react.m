%filename react.m
function der=react(W,var)
global Ta delH CPA FA0
x = var(1);
T = var(2);
y = var(3);
k = 0.5*exp(5032*(1/450 - 1/T));
temp = 0.271*(450/T)*y/(1-0.5*x);
CA = temp * (1-x);
CC = temp * 0.5 * x;
Kc = 25000*exp(delH/8.314*(1/450-1/T));
rA = -k*(CA*CA - CC/Kc);
row(1) = -rA/FA0;
row(2) = (0.8*(Ta-T)+rA*delH)/(CPA*FA0);
row(3) = -0.015*(1-0.5*x)*(T/450)/(2*y);
der=row';
