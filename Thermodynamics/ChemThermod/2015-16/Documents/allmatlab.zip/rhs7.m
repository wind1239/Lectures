% filename rhs7.m
function ydot=rhs7(z,y)
global k Dab 

row(1)=y(2);
row(2)=k*y(1)/Dab;
row(3)=y(4);
row(4)= k*y(3)/Dab;
ydot = row';

