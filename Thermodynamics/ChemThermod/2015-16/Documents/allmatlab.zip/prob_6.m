%	filename Prob_6.m
%	Heat Exchange in a Series of Tanks

clear

global W UA M Cp Tsteam num_tanks To

num_tanks = 3
W = 100;							%	kg/min
UA = 10;							%	kJ/min.C
M = 1000;							%	kg
Cp = 2.0;							%	kJ/kg
Tsteam = 250;						%	C
To = 20;							%	C

T_initial = ones(1,num_tanks)*To;

t_start = 0;						%	min
t_final = 90;						%	min
tspan = [t_start t_final];
[t,T] = ode45('tanks',tspan,T_initial);
% For Version 4, use
%[t,T] = ode45('tanks',t_start,t_final,T_initial);
plot(t,T)
title('Temperature in Stirred Tanks')
xlabel('time (min)')
ylabel('T (C)')
output = [t T];
save temps.dat output -ascii
