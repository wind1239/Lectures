%To solve part a, insert the data:
vp = [    1     5    10    20    40    60   100   200   400   760]
T = [-36.7  -19.6  -11.5   -2.6   7.6   15.4   26.1 42.2   60.6   80.1]
%vp =   1     5    10    20    40    60   100   200   400   760
%T =  -3.6700e+01  -1.9600e+01  -1.1500e+01  -2.6000e+00   7.6000e+00   1.5400e+01
%   2.6100e+01   4.2200e+01   6.0600e+01   8.0100e+01

%set the degree of polynomial: p(1) = a(n),...p(n+1) = a(0)
m = 4		% 'm' here is one less than 'n' in the problem statement

%fit the polynomial
p=polyfit(T,vp,m)
%p =   3.9631e-06   4.1312e-04   3.6044e-02   1.6062e+00   2.4679e+01

%evaluate the polynomial for every T (if desired)
z=polyval(p,T)
%z =   1.0477e+00   4.5184e+00   1.0415e+01   2.0739e+01   3.9162e+01   5.9694e+01
%   1.0034e+02   2.0026e+02   3.9977e+02   7.6005e+02

%calculate tne norm of the error
norm(vp-polyval(p,T))

%plot results
plot(T,z,'or',T,vp,'b')
Title('Vapor Pressure with m = 4')
xlabel('T (C)')
ylabel('vp (mm Hg)')
