%filename Prob_9.m
global Ta delH CPA FA0
%set parameters
Ta = 500;
delH = -40000;
CPA = 40;
FA0=5;

%set initial conditions
var0(1) = 0.;
var0(2) = 450;
var0(3) = 1.0;
Wspan = [0 20];

%integrate equations
[W var]=ode45('react',Wspan,var0)
% For version 4.0 use
%[W var]=ode45('react',0,20,var0)

%plot results
tt = var(:,2)/1000;
plot(W,var(:,1),'r',W,var(:,3),'g',W,tt,'b')
title ('Reactor Model')
xlabel ('W')
legend('Conversion of A','Normalized Pressure','T/1000')
% To plot concentration, issue command conc
