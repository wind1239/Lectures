%filename jac4.m
function J = jac4(cvector)
global Cao Cbo Kci Kcii Kciii

%  row 1
J(1,1)= -cvector(2)*Kci; J(1,2)= -cvector(1)*Kci; J(1,3)= cvector(4);
J(1,4)= cvector(3); J(1,5)=0; J(1,6)=0; J(1,7)=0;

%  row 2
J(2,1)= 0; J(2,2)= -Kcii*cvector(3); J(2,3)= -Kcii*cvector(2); J(2,4)=0;
J(2,5)= cvector(6); J(2,6)= cvector(5); J(2,7)=0;

% row 3
J(3,1)= -Kciii*cvector(5); J(3,2)=0; J(3,3)=0; J(3,3)=0; J(3,4)=0; 
J(3,5)= -Kciii*cvector(1); J(3,6)= 0; J(3,7)=1;

% row 4
J(4,1)= -1; J(4,2)= 0; J(4,3)= 0; J(4,4)=-1; J(4,5)=0; J(4,6)=0; J(4,7)=-1;

% row 5
J(5,1)=0; J(5,2)=-1; J(5,3)=0; J(5,4)=-1; J(5,5)=0; J(5,6)=-1; J(5,7)=0;

% row 6
J(6,1)=0; J(6,2)=0; J(6,3)=-1; J(6,4)=1; J(6,5)=0; J(6,6)=-1; J(6,7)=0;

% row 7
J(7,1)=0; J(7,2)=0; J(7,3)=0; J(7,4)=0; J(7,5)=-1; J(7,6)=1; J(7,7)=-1;

