function dT_dt = tanks(t,T)

global W UA M Cp Tsteam num_tanks To

for j = 1:num_tanks
	if j==1
		row(j) = (W*Cp*(To-T(j)) + UA*(Tsteam-T(j)))/(M*Cp);
	else
		row(j) = (W*Cp*(T(j-1)-T(j)) + UA*(Tsteam-T(j)))/(M*Cp);
	end
end
dT_dt = row';
