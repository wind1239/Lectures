function dL_dx = distill(x,L)

global A B C P T_guess x2

x2 = x;
T = fzero('vap_pres',T_guess);
P_i = 10.^(A-B./(T+C));
k = P_i./P;
dL_dx = L/x2/(k(2)-1);
