% filename waalsvol.m
function x=waalsvol(vol)
global press a b R T
x=press*vol^3-press*b*vol^2-R*T*vol^2+a*vol-a*b;

