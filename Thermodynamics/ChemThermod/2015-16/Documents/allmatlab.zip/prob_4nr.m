%filename Prob_4NR.m
clear all
clc
global Cao Cbo Kci Kcii Kciii cvector

% define constants
Cao = 1.5; Cbo=1.5; Kci= 1.06; Kcii= 2.63; Kciii= 5;

% Initial guess and set tolerance
err=1; 
iter=0;
% remove the % in front of the desired initial guess
cvector=[1.5 1.5 0 0 0 0 0]; %initial guess, part a
%cvector=[-.5 -1.5 -1 1 1 2 1];  %initial guess, part b
%cvector=[-18.5 -28.5 -10 10 10 20 10]; %initial guess, part c
guess=cvector;

while err > 1e-4 & iter < 200
   x= prob4(cvector);
   J= jac4(cvector);
   errr= -J\x';
   cvector=cvector+errr';
   errr=abs(errr);
   err= sqrt(sum(errr));
   iter=iter+1;
end

disp('guess')
disp(guess)
disp('error')
disp(err)
disp('   A          B         C         D         X        Y       Z');
disp(cvector);
disp('iter')
disp(iter)



