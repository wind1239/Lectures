%Problem 5
%Tae H Han
%University of Washington
%August 6, 1997
%
%
%	5.4 Problem Statement
%   A simple force balance on a spherical particle reaching terminal
%   velocity in a fluid is given by(13):
%
%	v_t=sqrt[(4g(rho_p-rho)D_p)/(3C_D*rho)]
%
%   where v_t is the terminal velocity in m/s, g is the acceleration of
%   gravity given by 9.80665 m/s^2, rho_p is the particles density in
%   kg/m^3, rho is the fluid density in kg/m^3, D_p is the diameter of the
%   spherical particle in m and C_D is a dimensionless coefficient.
%
%   The drag coefficient on a spherical particle at a terminal velocity
%   varies with the Reynolds number(Re) as follows(pp 5-63, 5-64 in
%   Perry):
%
%	C_D=24/Re 		 for Re<0.1		(14)
%	C_D=24*(1+0.14Re^0.7)/Re for 0.1<Re<1000	(15)
%	C_D=0.44 		 for 1000<Re<350000	(16)
%	C_D=0.19-80000/Re 	 for 350000<Re		(17)
%
%   where Re = D_p*v_t*rho/mu and mu is the viscosity in Pa*s.
%

%(a) Calculate the terminal velocity for particles of coa

%Input the known values
rho_p=1800;			%kg/m^3
D_p=0.208*10^(-3);	%m
T=298.15;			%K
rho=994.6;			%kg/m^3
mu=8.931*10^(-4);	%kg/m/s
g=9.80665;			%m/s^2

%Input an value of v_t and different value of v_t_g
v_t=10;				%m/s
v_t_g=20;			%m/s

%Rearrange equation 13 to solve for zero
%
%	f(v_t)=v_t^2*(3C_D*rho)-4g(rho_p-rho)D_p=0

%Begin while loop
tae=0;
while tae == 0

%Calculate Re from the guessed v_t_g
Re=D_p*v_t_g*rho/mu;

%Determine C_D
 if Re<0.1
	C_D=24/Re;
 elseif Re<1000 
	C_D=24*(1+0.14*Re^0.7)/Re;
 elseif Re<350000
	C_D=0.44;
 else
	C_D=0.19-80000/Re;
 end

%Calculate v_t
v_t=sqrt((4*g*(rho_p-rho)*D_p)/(3*C_D*rho));

 if (v_t == v_t_g)
	tae = 1;
 else
	v_t_g=v_t;
 end

end

v_t		%0.0158 m/s
Re		%3.6556
C_D		%8.8427

%(b) Estimate the terminal velocity of the coal particles in water within
%a centrifugal separator where the acceleration is 30.0g.
%
%To solve this problem, substitute 30.0*9.80655 for g in the above code.
%
%The results are:
%v_t = 0.2060 m/s
%Re = 47.7226
%C_D = 1.5566
