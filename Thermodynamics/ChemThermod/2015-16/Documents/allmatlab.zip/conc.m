%filename conc.m
x=var(:,1);
y=var(:,3);
T=var(:,2);
temp = 0.271*(450./T).*y./(1-0.5.*x);
CA = temp .* (1.-x);
CC = temp .* 0.5 .* x;
plot(W,CA,'r',W,CC,'g')
title ('Concentrations')
xlabel('W')
legend ('Conc. of A','Conc. of C')

