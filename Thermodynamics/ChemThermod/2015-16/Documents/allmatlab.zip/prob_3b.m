% file Prob_3b.m
%To solve part b, insert the data:
vp = [    1     5    10    20    40    60   100   200   400   760]
T = [-36.7  -19.6  -11.5   -2.6   7.6   15.4   26.1 42.2   60.6   80.1]
%vp =   1     5    10    20    40    60   100   200   400   760
%T =  -3.6700e+01  -1.9600e+01  -1.1500e+01  -2.6000e+00   7.6000e+00   1.5400e+01
%   2.6100e+01   4.2200e+01   6.0600e+01   8.0100e+01

% create the new variables
y = log10(vp);
x = 1./(T+273.15);

% fit the polynomial
p = polyfit(x,y,1)
% p = -2035.33  8.75201

%To compute the norm based on the logarithm of the vapor pressure
y-polyval(p,x)
norm(y - polyval(p,x))
% norm = 0.2464

%To compute the norm based on the vapor pressure
norm(vp-10.^(polyval(p,x)))
% norm = 224.3

